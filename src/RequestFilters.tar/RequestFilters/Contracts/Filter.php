<?php

namespace mPhpMaster\Support\RequestFilters\Contracts;

use mPhpMaster\Support\RequestFilters\AuthorizeWhenResolvedTrait;
use Illuminate\Database\Eloquent\Builder;

abstract class Filter implements AuthorizeWhenResolved
{
    use AuthorizeWhenResolvedTrait;

    /**
     * Apply the filter to a given Eloquent query builder.
     *
     * @param Builder $builder
     * @param mixed   $value
     *
     * @return Builder
     */
    abstract public function apply(Builder $builder, $value): Builder;
}
