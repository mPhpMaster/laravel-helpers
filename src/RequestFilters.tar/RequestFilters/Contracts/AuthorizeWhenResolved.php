<?php

namespace mPhpMaster\Support\RequestFilters\Contracts;

interface AuthorizeWhenResolved
{
    /**
     * Authorize the given filter instance.
     */
    public function authorizeResolved();
}
