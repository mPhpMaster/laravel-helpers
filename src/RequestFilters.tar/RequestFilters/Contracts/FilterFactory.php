<?php

namespace mPhpMaster\Support\RequestFilters\Contracts;

use mPhpMaster\Support\RequestFilters\Exceptions\NotFoundFilterException;
use mPhpMaster\Support\RequestFilters\Concrete\QueryFilterFactory as FilterFactoryConcrete;
use Illuminate\Database\Eloquent\Model;

interface FilterFactory
{
    /**
     * Create applied filter.
     *
     * @param string $filter
     * @param Model  $model
     *
     * @throws NotFoundFilterException
     *
     * @return Filter
     */
    public function make(string $filter, Model $model): Filter;

    /**
     * @param string $namespace
     *
     * @return FilterFactoryConcrete
     */
    public function setCustomNamespace(string $namespace = ''): FilterFactoryConcrete;

    /**
     * @param string $namespace
     */
    public function setNamespace(string $namespace): void;

    /**
     * @return string
     */
    public function getCustomNamespace(): string;
}
