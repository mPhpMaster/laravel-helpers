<?php
/*
 * Copyright (c) 2020. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

namespace mPhpMaster\Support\RequestFilters;

use Closure;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;
use Illuminate\Support\Arr;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Str;
use ReflectionMethod;

/**
 * Abstract implementation of a request filters class
 *
 * @package mPhpMaster\Support\RequestFilters\QueryFilters
 */
abstract class QueryFilters
{
    public function __construct()
    {

        duE(
            __METHOD__,
            func_get_args(),
            $this->getClassName()
        );
    }

    /**
     * Search key name.
     *
     * @return string
     */
    protected function filterName()
    {
        return $this->getClassName();
    }

    /**
     * Search key value.
     *
     * @return mixed
     */
    protected function filterValue()
    {
        return request($this->filterName());
    }

    /**
     * Search key value.
     *
     * @param string|object|null    $class = $this
     * @param Closure|callable|string|null $then = snake_case
     *
     * @return mixed|null
     */
    protected function getClassName($class = null, $then = "snake_case")
    {
        $then = $then && (is_callable($then) || isClosure($then)) ? $then : 'Str::snake';
        return $then && is_callable($then) ? call_user_func($then, class_basename($class ?? $this)) : $class;
    }

    /**
     * @param          $request
     * @param \Closure $next
     *
     * @return mixed
     */
    public function handle($request, Closure $next)
    {
        if ( !request()->has($this->filterName()) ) {
            return $next($request);
        }

        /** @var \Illuminate\Database\Eloquent\Builder $builder */
        return $this->applyFilters($builder = $next($request));

        $query = static::applyDecoratorsFromRequest($request, $builder/* = $next($request)*/);

        return static::getResults($query);
    }

    /**
     * @param \Illuminate\Database\Eloquent\Builder $builder
     *
     * @return \Illuminate\Database\Eloquent\Builder|mixed
     */
    protected abstract function applyFilters(\Illuminate\Database\Eloquent\Builder $builder);

    private static function applyDecoratorsFromRequest(Request $request, Builder $query)
    {
        foreach ($request->all() as $filterName => $value) {

            $decorator = static::createFilterDecorator($filterName);

            if (static::isValidDecorator($decorator)) {
                $query = $decorator::apply($query, $value);
            }

        }
        return $query;
    }

    private static function createFilterDecorator($name)
    {
        return __NAMESPACE__ . '\\Filters\\' . studly_case($name);
    }

    private static function isValidDecorator($decorator)
    {
        return class_exists($decorator);
    }

    private static function getResults(Builder $query)
    {
        return $query->get();
    }
}
