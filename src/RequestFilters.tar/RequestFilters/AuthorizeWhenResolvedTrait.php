<?php
/*
 * Copyright (c) 2020. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

namespace mPhpMaster\Support\RequestFilters;

use Illuminate\Auth\Access\AuthorizationException;

trait AuthorizeWhenResolvedTrait
{
    /**
     * authorize the filter instance.
     *
     * @throws AuthorizationException
     */
    public function authorizeResolved()
    {
        if (! $this->passesAuthorization()) {
            $this->failedAuthorization();
        }
    }

    /**
     * Determine if the filter passes the authorization check.
     *
     * @return bool
     */
    protected function passesAuthorization()
    {
        if (method_exists($this, 'authorize')) {
            return $this->authorize();
        }

        return true;
    }

    /**
     * Handle a failed authorization attempt.
     *
     * @throws \Illuminate\Auth\Access\AuthorizationException
     */
    protected function failedAuthorization()
    {
        throw new AuthorizationException('This filter action is unauthorized.');
    }
}
