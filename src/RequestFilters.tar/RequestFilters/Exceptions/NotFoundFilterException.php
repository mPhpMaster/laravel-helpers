<?php

namespace mPhpMaster\Support\RequestFilters\Exceptions;

use Exception;

class NotFoundFilterException extends Exception
{
}
