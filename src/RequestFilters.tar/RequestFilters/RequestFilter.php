<?php
/*
 * Copyright (c) 2020. Lorem ipsum dolor sit amet, consectetur adipiscing elit.
 * Morbi non lorem porttitor neque feugiat blandit. Ut vitae ipsum eget quam lacinia accumsan.
 * Etiam sed turpis ac ipsum condimentum fringilla. Maecenas magna.
 * Proin dapibus sapien vel ante. Aliquam erat volutpat. Pellentesque sagittis ligula eget metus.
 * Vestibulum commodo. Ut rhoncus gravida arcu.
 */

namespace mPhpMaster\Support\RequestFilters;

use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\Request;

/**
 * Class RequestFilter
 *
 * @package mPhpMaster\Support\RequestFilters
 */
class RequestFilter
{

    protected static ?string $namespace = __NAMESPACE__;

    /**
     * @param          $request
     * @param \Closure $next
     *
     * @return mixed
     */
    public function handle($request, \Closure $next)
    {
        static::apply($request);

        return $next($request);
    }

    /**
     * @param \Illuminate\Http\Request $filters
     *
     * @return \Illuminate\Database\Eloquent\Builder[]|\Illuminate\Database\Eloquent\Collection
     */
    public static function apply(Request $filters)
    {
        $query =
            static::applyDecoratorsFromRequest(
                $filters, app("User")->newQuery()
            );

        return static::getResults($query);
//        return static::getResults($query);
    }

    /**
     * @param \Illuminate\Http\Request              $request
     * @param \Illuminate\Database\Eloquent\Builder $query
     *
     * @return \Illuminate\Database\Eloquent\Builder
     */
    private static function applyDecoratorsFromRequest(Request $request, Builder $query)
    {
        foreach ($request->all() as $filterName => $value) {

            $decorator = static::createFilterDecorator($filterName);

            if ( static::isValidDecorator($decorator) ) {
                $query = $decorator::apply($query, $value);
            }

        }
        return $query;
    }

    /**
     * @param $name
     *
     * @return string|void
     */
    private static function createFilterDecorator($name)
    {
        return static::$namespace . '\\RequestFilters\\' .
            str_replace(' ', '',
                ucwords(str_replace('_', ' ', $name)));
    }

    /**
     * @param $decorator
     *
     * @return bool
     */
    private static function isValidDecorator($decorator)
    {
        return class_exists($decorator);
    }

    /**
     * @param \Illuminate\Database\Eloquent\Builder $query
     *
     * @return \Illuminate\Database\Eloquent\Builder[]|\Illuminate\Database\Eloquent\Collection
     */
    private static function getResults(Builder $query)
    {
        return $query->get();
    }

    /**
     * @param string $namespace
     *
     * @return string
     */
    public static function setNamespace(string $namespace)
    {
        static::$namespace = $namespace;

        return static::class;
    }
}
