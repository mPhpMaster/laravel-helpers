<?php

namespace mPhpMaster\Support\RequestFilters;

use Illuminate\Database\Schema\Builder;
use Illuminate\Routing\Router;
use Illuminate\Support\Arr;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\Schema;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;
use mPhpMaster\Support\RequestFilters\Concrete\QueryFilterFactory;
use mPhpMaster\Support\RequestFilters\Contracts\FilterFactory as Factory;
use mPhpMaster\Support\RequestFilters\QueryFilter;
use mPhpMaster\Support\RequestFilters\RequestFilter;
use mPhpMaster\Support\RequestFilters\QueryFilters;

/**
 * Class MPhpMasterHelpersProvider
 *
 * @package mPhpMaster\Support\Providers
 */
class Provider extends ServiceProvider
{
    /**
     * Register services.
     *
     * @return void
     */
    public function register()
    {
        $this->registerBindings();
    }

    /**
     * Bootstrap services.
     *
     * @param Router $router
     *
     * @return void
     */
    public function boot(Router $router)
    {
        $this->bootPublishes();
    }


    /**
     * @return array
     */
    public function provides()
    {
        return [];
    }

    /**
     *
     */
    private function registerBindings()
    {
        $this->app->bind(Factory::class, QueryFilterFactory::class);

//        $this->app->singleton('eloquentbuilder', static function () {
//            return new QueryFilter(new FilterFactory());
//        });

        $this->app->singleton(
            'requestFilter',
            function () {
//                return new QueryFilters(new QueryFilterFactory());
//                return new RequestFilter;//($this->app->get('request'));
            }
        );
    }

    protected function bootPublishes(): void
    {
        $configPath = $this->configPath();

        $this->mergeConfigFrom($configPath, 'query-filters');

        $this->publishes([$configPath => config_path('query-filters.php')], 'config');
    }

    /**
     * @return string
     */
    protected function configPath(): string
    {
        return __DIR__.'/config/query-filters.php';
    }
}
